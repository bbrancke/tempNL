// Nl80211Base.h
// Base class sets up connection to nl80211 sub-system.

#ifndef NL80211BASE_H_
#define NL80211BASE_H_

#include <iostream>
#include <string>
#include <sstream>

#include <netlink/netlink.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/family.h>
#include <netlink/genl/ctrl.h>

#include "Log.h"

using namespace std;

class Nl80211Base : protected Log
{
public:
	Nl80211Base(const char* name);
};

#endif  // NL80211BASE_H_

