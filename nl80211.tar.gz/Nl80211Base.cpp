// Nl80211Base.cpp

// Base class sets up connection to nl80211 sub-system.

#include "Nl80211Base.h"

Nl80211Base::Nl80211Base(const char* name) : Log(name)
{ }

